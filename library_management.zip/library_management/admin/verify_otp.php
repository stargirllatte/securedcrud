<?php
session_start();

if (!isset($_SESSION['otp'])) {
    header("Location: index.php");
    exit();
}

if (isset($_POST['verify_btn'])) {
    $otp_entered = $_POST['otp'];
    if ($otp_entered == $_SESSION['otp']) {
        // Set otp_verified session variable to indicate successful OTP verification
        $_SESSION['otp_verified'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        $error_msg = "Invalid OTP. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Library Management System</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/custom_style.css?ver=1.1" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css' rel='stylesheet' />
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
</head>

<body class="bg-dark" style="background: url(../img/library-img-bg.jpg) no-repeat;  background-size:cover">

    <div class="container">
        <div class="card card-login mx-auto mt-5">
            <div class="card-header">
                <h2>
                    <center style="color:coral;">Admin Verification</center>
                </h2>
            </div>
            <div class="card-body">
                <?php if (isset($error_msg)) : ?>
                    <p style="color: red;"><?php echo $error_msg; ?></p>
                <?php endif; ?>
                <form method="post">
                    <div class="form-group">
                        <div class="form-label-group">
                            <input type="number" id="otp" class="form-control" placeholder="OTP" name="otp" required="required">
                            <label for="otp">Enter OTP</label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" name="verify_btn">Verify OTP</button>
                </form>

            </div>
        </div>
    </div>


</body>

</html>