<?php
session_start();
include '../connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../email/phpmailer/src/Exception.php';
require '../email/phpmailer/src/PHPMailer.php';
require '../email/phpmailer/src/SMTP.php';

if (isset($_POST['login_btn'])) {
  $email = $_POST['email'];
  $password = $_POST['pwd'];

  $select_query = mysqli_query($conn, "SELECT user_name, id, emailid, password FROM tbl_users WHERE emailid='$email' AND role=1 AND status=1");
  $user_details = mysqli_fetch_assoc($select_query);

  if ($user_details && password_verify($password, $user_details['password'])) {
    // Generate OTP
    $otp = mt_rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['user_name'] = $user_details['user_name'];
    $_SESSION['id'] = $user_details['id'];

    // Send OTP to user's email
    $mail = new PHPMailer(true);
    try {
      //Server settings
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = true;
      $mail->Username = 'librarymanagement50@gmail.com';
      $mail->Password = 'msppcbdmlwrdoble';
      $mail->SMTPSecure = 'ssl';
      $mail->Port = 465;

      //Recipients
      $mail->setFrom('librarymanagement50@gmail.com', 'Libary Management System');
      $mail->addAddress($user_details['emailid'], $user_details['user_name']); // Add a recipient

      //Content
      $mail->isHTML(true);
      $mail->Subject = 'OTP Verification';
      $mail->Body    = 'Your OTP is: ' . $otp;

      $mail->send();
    } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    header("Location: verify_otp.php");
    exit();
  } else {
    echo "<script>alert('You have entered wrong emailid or password.');</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">


  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Library Management System</title>
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
  <link href="css/custom_style.css?ver=1.1" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css' rel='stylesheet' />
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
</head>

<body class="bg-dark" style="background: url(../img/library-img-bg.jpg) no-repeat;  background-size:cover">

  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">
        <h2>
          <center style="color:coral;">Admin Login</center>
        </h2>
      </div>
      <div class="card-body">
        <form name="login" method="post" action="">
          <div class="form-group">
            <div class="form-label-group">
              <input type="email" id="inputEmail" class="form-control" name="email" placeholder="Email address" required="required" autofocus="autofocus">
              <label for="inputEmail">Email address</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="pwd" required="required">
              <label for="inputPassword">Password</label>
            </div>
          </div>

          <input type="submit" class="btn btn-primary btn-block" name="login_btn" value="Login">
        </form>

      </div>
    </div>
  </div>
</body>

</html>