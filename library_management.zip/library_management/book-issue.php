<?php
session_start();
include('connection.php');

$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['id'];
$book_id = $_GET['id'];

$insert_issue_stmt = $conn->prepare("INSERT INTO tbl_issue (book_id, user_id, user_name, status) VALUES (?, ?, ?, 3)");
$insert_issue_stmt->bind_param("iis", $book_id, $user_id, $user_name);
$insert_issue_stmt->execute();

if ($insert_issue_stmt->affected_rows > 0) {
?>
    <script type="text/javascript">
        alert("Book issued successfully.");
        window.location.href = "book.php";
    </script>
<?php
}
?>