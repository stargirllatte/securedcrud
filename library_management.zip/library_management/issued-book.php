<?php
include('include/header.php');
include('functions/sanitize-html.php');
?>

<div id="wrapper">
  <?php include('include/side-bar.php'); ?>
  <div id="content-wrapper">
    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">View Book</a>
        </li>
      </ol>
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-info-circle"></i>
          View Book Details
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Book Name</th>
                  <th>Category</th>
                  <th>Issue Date</th>
                  <th>Due Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $select_query_stm = $conn->prepare("select tbl_issue.book_id, tbl_book.book_name, tbl_book.category, tbl_issue.issue_date, tbl_issue.due_date from tbl_issue inner join tbl_book on tbl_issue.book_id=tbl_book.id where tbl_issue.user_id=? and tbl_issue.status=1");
                $select_query_stm->bind_param("i", $user_id);
                $select_query_stm->execute();
                $select_query_stm->bind_result($book_id, $book_name, $category, $issue_date, $due_date);
                $i = 1;
                while ($select_query_stm->fetch()) {
                ?>
                  <tr>
                    <td><?php echo sanitizeHtml($book_id) ?></td>
                    <td><?php echo sanitizeHtml($book_name) ?></td>
                    <td><?php echo sanitizeHtml($category) ?></td>
                    <td><?php echo sanitizeHtml($issue_date) ?></td>
                    <td><?php echo sanitizeHtml($due_date) ?></td>
                    <td><a href="book-return.php?id=<?php echo sanitizeHtml($book_id); ?>"><button class="btn btn-success">Return</button></a>
                    </td>
                  </tr>
                <?php $i++;
                }
                $select_query_stm->close();
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php include('include/footer.php'); ?>