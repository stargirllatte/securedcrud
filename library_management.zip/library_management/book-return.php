<?
session_start();
include('connection.php');

$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['id'];
$book_id = $_GET['id'];

// using prepared statements to prevent SQL injection

$delete_book_stmt = $conn->prepare("DELETE FROM tbl_book WHERE id=? AND user_id = ?");
$delete_book_stmt->bind_param("ii", $book_id, $user_id);
$delete_book_stmt->execute();

$insert_return_book_stmt = $conn->prepare("INSERT INTO tbl_return_book (book_id, user_id,user_name, return_date) VALUES (?, ?, ?, CURDATE())");
$insert_return_book_stmt->bind_param("iis", $book_id, $user_id, $user_name);
$insert_return_book_stmt->execute();

$select_quantity_stmt = $conn->prepare("SELECT quantity FROM tbl_book WHERE id = ?");
$select_quantity_stmt->bind_param("i", $book_id);
$select_quantity_stmt->execute();
$select_quantity_stmt->bind_result($quantity);
$select_quantity_stmt->fetch();
$select_quantity_stmt->close();

$quantity = $quantity + 1;

$update_quantity_stmt = $conn->prepare("UPDATE tbl_book SET quantity = ? WHERE id = ?");
$update_quantity_stmt->bind_param("ii", $quantity, $book_id);
$update_quantity_stmt->execute();

$update_issue_stmt = $conn->prepare("UPDATE tbl_issue SET status = 0 WHERE book_id = ?");
$update_issue_stmt->bind_param("i", $book_id);
$update_issue_stmt->execute();

if ($update_issue_stmt->affected_rows > 0) {
?>
    <script type="text/javascript">
        alert("Book returned successfully.");
        window.location.href = "book-return.php";
    </script>
<?php
} else {
?>
    <script type="text/javascript">
        alert("Failed to return book.");
        window.location.href = "book-return.php";
    </script>
<?php
    $conn->close();
}
?>