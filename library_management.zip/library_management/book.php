<?php
include('include/header.php');
include('functions/sanitize-html.php')
?>

<div id="wrapper">
  <?php include('include/side-bar.php'); ?>
  <div id="content-wrapper">
    <div class="container-fluid">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">View Book</a>
        </li>
      </ol>
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-info-circle"></i>
          View Book Details
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Availability</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                if (isset($_GET['id'])) {
                  $book_id = $_GET['id'];
                  $delete_book_stmt = $conn->prepare("delete FROM tbl_book WHERE id=?");
                  $delete_book_stmt->bind_param("i", $book_id);
                  $delete_book_stmt->execute();
                }

                $select_book_stmt = $conn->prepare("SELECT id, book_name, category, quantity, availability FROM tbl_book WHERE availability = 1");
                $select_book_stmt->execute();
                $select_book_stmt->bind_result($id, $book_name, $category, $quantity, $availability);
                $i = 1;
                while ($select_book_stmt->fetch()) {
                ?>
                  <tr>
                    <td><?php echo sanitizeHtml($i) ?></td>
                    <td><?php echo sanitizeHtml($book_name) ?></td>
                    <td><?php echo sanitizeHtml($category) ?></td>
                    <td>
                      <?php
                      if ($availability == 1) {
                        echo '<span class="badge badge-success">Available</span>';
                      } else {
                        echo '<span class="badge badge-danger">Not Available</span>';
                      }
                      echo "</td>";

                      $select_issue_details_stmt = $conn->prepare("SELECT issue_date, due_date FROM tbl_issue WHERE book_id = ? AND user_id = ?");
                      $select_issue_details_stmt->bind_param("ii", $id, $user_id);
                      $select_issue_details_stmt->execute();
                      $select_issue_results = $select_issue_details_stmt->get_results();
                      $res = $select_issue_results->fetch_row();

                      if (!empty($res)) {
                        $res = $res[0];
                      }
                      ?>
                    <td>
                      <?php if ($res == 1) : ?>
                        <span class="badge badge-success">Issued</span>
                      <?php elseif ($res == 2) : ?>
                        <span class="badge badge-danger">Rejected</span>
                      <?php elseif ($res == 3) : ?>
                        <span class="badge badge-primary">Request Sent</span>
                      <?php else : ?>
                        <a href="book-issue.php?id=<?php echo sanitizeHtml($row['id']); ?>"><button class="btn btn-success">Issue</button></a>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php
                }
                $i++;
                $select_book_stmt->close();
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php include('include/footer.php'); ?>
  <script language="JavaScript" type="text/javascript">
    function confirmDelete() {
      return confirm('Are you sure want to delete this Book?');
    }
  </script>