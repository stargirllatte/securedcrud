<?php
function sanitizeHtml($data, $encoding = 'UTF-8')
{
    return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, $encoding);
}
